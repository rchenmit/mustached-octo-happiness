import javax.swing.*;
public class SoftDrinkAnalysis {
	public static final double cubePackEfficiency = 1.0;
	public static final double cylinderPackEfficiency = Math.PI / 4;
	
	public static void main(String[] args) {
		//double volume;//volume
		//double matCost;//material cost
		//double refCost;//refridgerator cost
		
		//NEED TO READ THESE FROM JOPTIONPANE
		String input = JOptionPane.showInputDialog("Enter volume: ");
		double volume = Double.parseDouble(input); // Enter 4 (hrs)
		input = JOptionPane.showInputDialog("Enter material cost: ");
		double matCost = Double.parseDouble(input); // Enter 4 (hrs)
		input = JOptionPane.showInputDialog("Enter cooling cost: ");
		double refCost = Double.parseDouble(input); // Enter 4 (hrs)
		//volume = 26;
		//matCost = 0.1;
		//refCost = 1.5;
		
		//current soft drink dims
		double currentSoftRadius = 1.3;
		double currentSoftHeight = 4.9;
		double currentSoftArea = findAreaCylinder(currentSoftRadius,currentSoftHeight );
		//current juice dims
		double currentJuiceWidth = 3.5;
		double currentJuiceHeight = 4.6;
		double currentJuiceDepth = 1.6;
		double currentJuiceArea = findAreaCuboid(currentJuiceWidth, currentJuiceHeight, currentJuiceDepth);
		
		System.out.println("current soft drink SA: " + currentSoftArea);
		System.out.println("current juice SA: " + currentJuiceArea);
		
		double [] optDimCylinder = new double[10];
		double [] optDimCuboid = new double[10];
		
		optDimCylinder = findOptDimForVol(volume, "cylinder");
		optDimCuboid  = findOptDimForVol(volume, "cuboid");
		
		double newSoftArea = findAreaCylinder(optDimCylinder[0], optDimCylinder[1]);
		double newJuiceArea = findAreaCuboid(optDimCuboid[0], optDimCuboid[1], optDimCuboid[2]);
		//calculate percent reduction in SA
		double percentCylinderSA = percentReduction(currentSoftArea,newSoftArea);
		double percentCuboidSA = percentReduction(currentJuiceArea, newJuiceArea);
		
		System.out.println("new SA cylinder: " + newSoftArea);
		System.out.println("new SA cuboid: " + newJuiceArea);
		System.out.println("percent reduction cylinder: " + percentCylinderSA );
		System.out.println("percent reduction cuboid: "  + percentCuboidSA );
		
		//check if cuboid or cylinder is cheaper
		

		String cheaper = findOptContType(volume, matCost,refCost,newSoftArea, newJuiceArea );
		System.out.println("The shape " + cheaper + " is cheaper!!");

		/*
		double [] optDimCostCyl = new double[10];
		double [] optDimCostCube = new double[10];
		optDimCostCyl = findOptDimForCost(volume, newSoftArea, matCost, refCost, "cylinder");
		optDimCostCube = findOptDimForCost(volume, newJuiceArea, matCost, refCost, "cuboid");
		System.out.println("opt dims for cost cylinder: r=" + optDimCostCyl[1] + "; h=" + optDimCostCyl[2]);
		System.out.println("opt dims for cost cuboid: w=" + optDimCostCube[1] + ";h= " + optDimCostCube[2] + "; d= " + optDimCostCube[3]);
		*/
		
		double breakEvenRatio =  findBreakEvenRatio (currentSoftArea, currentJuiceArea, matCost, refCost);
		System.out.println("break even ratio: " + breakEvenRatio);
		return;
	}
	public static double findBreakEvenRatio (double cylArea, double cubeArea, double matCost, double refCost) {
		//set the 2 costs to be equal, we will fix matCost to be constant, and solve for the matCost that makes the cost of the containers equal
		//SA_cyl * matCost + refCost /cylinderPackEfficiency = SA_cube*matCost + refCost/cubePackEfficiency
		
		double refCostCylinder = refCost / cylinderPackEfficiency;
		double refCostCube = refCost / cubePackEfficiency;
		//double newRefCost = matCost * (cylArea-cubeArea) / (1 - 1/(cylinderPackEfficiency));
		double newRefCost = matCost * (cubeArea-cylArea) / (1/(cylinderPackEfficiency)-1);

		System.out.println("Breakeven cooling cost: " + newRefCost);
		double newCostCube = cubeArea * matCost + newRefCost;
		double newCostCyl = cylArea * matCost + newRefCost / cylinderPackEfficiency;
		System.out.println("new cost cube: " + newCostCube);
		System.out.println("new cost cylinder: " + newCostCyl);
		double breakEvenRatio = matCost / newRefCost;
		System.out.println("breakeven ratio material cost / cooling cost: " + breakEvenRatio);
		return breakEvenRatio;
	}	
///////////////////////////////////////////////
	public static String findOptContType (double volume, double matCost, double refCost, double cylinderSA, double cubeSA) {
		//account for diff in space efficiency!!

		
		double matCostCylinder = cylinderSA * matCost;
		double matCostCube = cubeSA * matCost;
		double refCostCylinder = refCost / cylinderPackEfficiency;
		double refCostCube = refCost / cubePackEfficiency;
		double priceCylinder = matCostCylinder + refCostCylinder;
		double priceCube = matCostCube + refCostCube;
		
		System.out.println("price cylinder: " + priceCylinder + ";   price cuboid: " + priceCube + " cents");
		if (priceCylinder < priceCube) {
			return "CYLINDER";
		}
		else if (priceCylinder > priceCube) {
			return "CUBOID";
		}
		else {
			return "BOTH EQUAL COST";
		}
	}
/////////////////////////////////////////////

	public static double[] findOptDimForCost (double volumeGoal , double surfaceArea, double matCost, double refCost, String containerType) {
		double [] optDims = new double[10];
		//double r, h;
		double smallestCost = Double.MAX_VALUE;
		double rbest = 0, hbest = 0;
		double wbest = 0, dbest = 0;
		double refCostCyl = refCost / cylinderPackEfficiency;
		double refCostCube = refCost / cubePackEfficiency;
		if (containerType == "cylinder") {
			for (double r = 0.1; r <= 10; r += 0.1) {
				double h = volumeGoal / (Math.PI * r * r);
				double currentCost = matCost * surfaceArea + refCostCyl;
				//System.out.println("r: " + r + "   h:  " + h + " currCost: " + currentCost + "  smallestCost:  " + smallestCost + "   vol: " + findVolumeCylinder(r,h) );
				if (currentCost < smallestCost) {
					smallestCost = currentCost;
					rbest = r;
					hbest = h;
				}
			}
			optDims[0] = smallestCost;
			optDims[1] = rbest;
			optDims[2] = hbest;
		}
		else if (containerType == "cuboid") {
			for (double w = 0.1; w <= 10; w += 0.1) {
				for (double h = 0.1; h <= 10; h+=0.1) {
					double d = volumeGoal / w / h;
					double currentCost = matCost * surfaceArea + refCostCube;
					//System.out.println("w: " + w + "   h:  " + h + "   d:" + d + "   currCost: " + currentCost + "  smallestCost:  " + smallestCost + "   vol: " + findVolumeCuboid(w,h,d) );
					if (currentCost < smallestCost) {
						smallestCost = currentCost;
						wbest = w;
						hbest = h;
						dbest = d;
					}
				}
			}
			optDims[0] = smallestCost;
			optDims[1] = wbest;
			optDims[2] = hbest;
			optDims[3] = dbest;
		}
		else {
			//throw exception
		}
		return optDims; 
	}


	public static double percentReduction (double initialSA, double newSA) {
		return (initialSA - newSA) / initialSA * 100;
	}
	
	public static double findVolumeCylinder (double radius, double height) {
		return Math.PI * radius * radius * height;
	}
	public static double findVolumeCuboid (double w, double h , double d) {
		return w*h*d;
	}
	public static double findAreaCylinder (double r, double h) {
		return 2 * Math.PI * r * h;
	}
	public static double findAreaCuboid (double w, double h, double d) {
		return 2 * (w*h + h*d + w*d);
	}

	public static double[] findOptDimForVol (double volumeGoal, String containerType){
		//optimal is h = 2r

		
		double [] optDims = new double[10];
		double surfaceArea = 0;
		//double r, h;
		double smallestSA = Double.MAX_VALUE;
		double rbest = 0, hbest = 0;
		double wbest = 0, dbest = 0;
		if (containerType == "cylinder") {
			double r = Math.pow((volumeGoal/(2*Math.PI)), 1/3);
			double h = 2 * r;
			optDims[0] = r;
			optDims[1] = h;
		}
		else if (containerType == "cuboid") {
			double w = Math.pow(volumeGoal, 1/3);
			double h = w;
			double d = w;
			optDims[0] = w;
			optDims[1] = h;
			optDims[2] = d;
		}
		else {
			//throw exception
		}

		return optDims; 
	}
	
}