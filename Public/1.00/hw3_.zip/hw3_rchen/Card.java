import java.util.*;
public class Card {
	public int cardNumber;
	public int roomNumber;
	public int date; 
	public int prevCode;
	public int newCode;
	public boolean valid = true;
	
	public Card (int cardNum, int roomNum, int date, int code) {
		this.cardNumber = cardNum;
		this.roomNumber = roomNum;
		this.date = date;
		this.prevCode = -1;
		this.newCode = code;
		
	}
	public void setNewCode (int newCode) {
		this.prevCode = this.newCode;
		this.newCode = newCode;
	}
	public boolean useCardOnRoom(int roomNum, DoorLock lock) {
		//check if it will open the room
		System.out.println("LOCK: room " + lock.getRoomNumber() + "; lock code: " + lock.getCurrentCode()+ "; lock date: " + lock.getDate());
		System.out.println("CARD: room " + this.roomNumber + ";prevcode " + prevCode + ";new code " + newCode + ";card date " + date);
		
		//first check if room numbers are same
		if (this.valid) { 
			if (this.roomNumber == lock.getRoomNumber()) {
				if (date > lock.getDate()) {
					if (prevCode == lock.getCurrentCode()) {
						//lock code = previous code of new guest AND update date on door lock
						lock.setNewCode(this.newCode, this.date);
						return true;
					}
					else return false;
				}
				else {//if date on card is same [or before - not implemented] as lock
					System.out.print("date not later");
					if (newCode == lock.getCurrentCode()) {
						return true; //date on card is same day or before
					}
					else {
						return false;
					}
				}
			}
			else return false;
		}
		else {
			return false;
		}
	}
	public int getPrevCode() {
		return prevCode;
	}
	public int getNewCode() {
		return newCode;
	}
	public int getDate() {
		return date;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public int getCardNumber() {
		return cardNumber;
	}
	public void makeInvalid() {
		this.valid = false;
	}
	public boolean checkValid() {
		return this.valid;
	}
}
