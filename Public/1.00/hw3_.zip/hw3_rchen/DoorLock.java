
public class DoorLock {
	public int roomNumber;
	public int code;
	public int date;

	
	public DoorLock (int room, int code, int date) {
		this.roomNumber = room;
		this.code = code;
		this.date = date;
	}
	public void setNewCode(int newcode, int date) {
		this.code = newcode;
		this.date = date; 
	}
	public int getCurrentCode() {
		return code;
	}
	public int getDate() {
		return date;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
}
