import java.util.*;

public class FrontDesk {
	public double latestCode;
	public Map<Integer, Integer> roomHash = new HashMap<Integer, Integer>();
	public int room10code = 1234;
	public int room11code = 4321;	
	//public Card roomCard;
	
	public FrontDesk () {
		//initialize rooms!!
		roomHash.put(10, room10code);
		roomHash.put(11, room11code);

	}
	public int genCode () {
		Random randNumber = new Random();
		int randCode = randNumber.nextInt();
		randCode = Math.abs(randCode);
		return randCode;
	}
	public Card issueCard(int cardNumber, int roomNumber, int date, DoorLock lock) {
		//random generate a new code FOR THE CARD:
		int randNewCode = genCode();
		Card newCard = new Card(cardNumber,roomNumber, date, randNewCode);
		//newCard.setNewCode(randNewCode);
		roomHash.put(roomNumber, randNewCode);
		
		////set the DOOR LOCK
		//lock.setNewCode(randNewCode, date);
		return newCard;
	}
	public Card issueCard(int cardNumber, int roomNumber, int date, DoorLock lock, Card card) {
		//random generate a new code FOR THE CARD:
		int randNewCode = genCode();
		int cardOldCode = card.getNewCode();
		Card newCard = new Card(cardNumber,roomNumber, date, cardOldCode);
		newCard.setNewCode(randNewCode);
		roomHash.put(roomNumber, randNewCode);
		
		////set the DOOR LOCK
		//lock.setNewCode(randNewCode, date);
		return newCard;
	}
}	
