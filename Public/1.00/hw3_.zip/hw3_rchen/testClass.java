
public class testClass {

	
	public static void main(String[] args) {
		//hotel with only two rooms: room10 and room11
		FrontDesk hotelDesk = new FrontDesk();
		DoorLock room10lock = new DoorLock(10, -1, -1);
		DoorLock room11lock = new DoorLock(11, -1, -1);
		Card card5 = hotelDesk.issueCard(5, 10, 0, room10lock);	
		System.out.println("front desk issue card 5 for room 10 on day 0: ");

		System.out.println("Card: " + card5.getCardNumber() + "; for room " + 
				card5.getRoomNumber() + "; on date: " + 
				card5.getDate() + "; with code: " + card5.getNewCode() + "\n----");
		System.out.println("ok");
		//card 5 is used on room 10 (whose lock it should open) and on room 11 (whose lock should not open)

		//front desk now issue card 5 for room 10 on day 0;
		//Card card5 = hotelDesk.issueCard(5, 10, 0, room10lock);
		System.out.println("use card5 on room 10: on date: " + card5.getDate() + ":" + card5.useCardOnRoom(10, room10lock) + "\n------");
		System.out.println("use card5 on room 11: on date: " + card5.getDate() + ":" + card5.useCardOnRoom(11, room11lock) + "\n------");
		
		//front desk issues card 6 for room 10 on day 1
		card5.makeInvalid();//make card5 invalid b/c we are about to issue card6 which goes to same room
		Card card6 = hotelDesk.issueCard(6, 10, 1, room10lock, card5);
		System.out.println("use card6 on room 10 on date: " + card6.getDate() + ": " + card6.useCardOnRoom(10, room10lock) + "\n------");
		System.out.println("use card6 on room 11 on date: " + card6.getDate() + ": " + card6.useCardOnRoom(11, room11lock)  + "\n------");
		
		//use card 6 AGAIN on room 10 and on room 11
		System.out.println("use card6 AGAIN on room 10 on date: " + card6.getDate() + ":" + card6.useCardOnRoom(10, room10lock) + "\n------");
		System.out.println("use card6 on AGAIN on room 11 on date: " + card6.getDate() + ": " + card6.useCardOnRoom(11, room11lock) + "\n------");		
		
	}

}
