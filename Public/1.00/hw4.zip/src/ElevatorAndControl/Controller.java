package ElevatorAndControl;
import java.util.ArrayList;
import TestAndEvent.*;

public class Controller {
	private static ArrayList<Event> listOfEvents = new ArrayList<Event>();
	//methods to move elevators
	
	public Controller() {
	}
	
	//public void floorRequest (Elevator []elevArr, int floor) {
		//int currFloor = floor;
	//	int requestFloor = floor;
	//	selectClosestElevator(elevArr, requestFloor);
	//}
	public void addEvent (Elevator [] elevArr, int floorPersonOnNow) {
		Elevator chosenElev = selectClosestElevator(elevArr, floorPersonOnNow);
		Event newEvent = new Event(chosenElev, floorPersonOnNow);
		chosenElev.doRequest(newEvent);
		listOfEvents.add(newEvent);
		System.out.println(newEvent);
	}
	public Elevator selectClosestElevator (Elevator []elevArr, int reqFloor) {
		//find the closest elevator
		int floorDiff = 999;
		Elevator closestElev = new Elevator("dummy");
		for (Elevator e: elevArr) {
			int currDiff = Math.abs(reqFloor - e.getCurrentFloor());
			if ( currDiff < floorDiff ) {
				floorDiff = currDiff;
				closestElev = e; //closest elevator
			}
		}
		return closestElev;
	}
	public static void printListOfEvents() {
		for (Event e: listOfEvents) {
			System.out.println(e);
		}
	}
}

