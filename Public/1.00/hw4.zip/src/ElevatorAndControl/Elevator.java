package ElevatorAndControl;
import java.util.*;
import java.math.*;
import java.lang.*;
import TestAndEvent.*;

public class Elevator {
	private int currentFloor = -1;
	private int numRequests = -1;
	private int numFloorsMoved = -1;
	private double avgFloorsPerRequest = -1;
	private String name;
	
	public Elevator(String name){
		Random randNum = new Random();
		int randInt = Math.abs(randNum.nextInt());
		int startFloor = randInt % 9 + 1;
		this.currentFloor = startFloor;
		this.numRequests = 0;
		this.numFloorsMoved = 0;
		this.avgFloorsPerRequest = 0;
		this.name = name;
	}
	public void doRequest(Event request) {
		this.numRequests += 1;
		int newFloor = request.getFinalFloor();
		System.out.println("final floor" + newFloor);
		int floorDiff = Math.abs(this.currentFloor - newFloor);
		this.numFloorsMoved += floorDiff;
		this.avgFloorsPerRequest = (double)this.numFloorsMoved / (double)this.numRequests;
		this.currentFloor = newFloor;
	}
	
	public int getCurrentFloor() {
		return this.currentFloor;
	}
	public int getNumRequests() {
		return this.numRequests;
	}
	public int getNumFloorsMoved() {
		return this.numFloorsMoved;
	}
	public double getAvgFloorsPerRequest() {
		return this.avgFloorsPerRequest;
	}
	public String getName() {
		return this.name;
	}
	public String toString() {
		return "Elev name: " + this.name + "; curr floor: " + currentFloor + "; numFloorsMoved:" + numFloorsMoved + "; avg floors/req: " + avgFloorsPerRequest;		
	}
	
	
}
