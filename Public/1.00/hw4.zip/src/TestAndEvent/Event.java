package TestAndEvent;
import ElevatorAndControl.*;
import java.util.Random;


public class Event {
	private static int ID = 0;
	private Elevator elevatorChosen;
	private int currentFloor = 0; //floor where elevator is now
	private int requestFloor = 0; //floor where passenger requests
	private int finalFloor = 0; //when passenger leaves
	private int thisEventID = -1;
	
	public Event(Elevator chosen, int requestFloor) {
		setID(getID()+1);
		this.thisEventID = getID();
		this.elevatorChosen = chosen;
		this.requestFloor = requestFloor;
		int destination = chooseDestination();
		this.finalFloor = destination;
		this.currentFloor = chosen.getCurrentFloor();
		
	}
	//public void selectClosestElevator () {
		//choose closest
	//}
	public int chooseDestination() {
		Random randNum = new Random();
		return Math.abs(randNum.nextInt()) % 9 + 1;
	}
	public int getFinalFloor() {
		return this.finalFloor;
	}
	public int getCurrentFloor() {
		return this.currentFloor;
	}
	public int getRequestFloor() {
		return this.requestFloor;
	}
	public Elevator getElevatorChosen() {
		return this.elevatorChosen;
	}

	public static void setID(int iD) {
		ID = iD;
	}
	public static int getID() {
		return ID;
	}
	public int getEventID() {
		return this.thisEventID;
	}
	public String toString() {
		return "EVENT: ID: " + getEventID() + ";Elevator: " + elevatorChosen.getName() + ";Current Floor: " + currentFloor + "; Request Floor: " + requestFloor + ";Final floor: " + finalFloor;
	}
}
