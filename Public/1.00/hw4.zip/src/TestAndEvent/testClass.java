package TestAndEvent;
import javax.swing.*;
import ElevatorAndControl.*;

public class testClass {
	public static void main(String[] args) {
		System.out.println("This is the test class");
		System.out.println("We will now input floors to go to");
		
		//make new elevators
		Elevator A1 = new Elevator("1A");
		Elevator B1 = new Elevator("1B");
		Elevator C1 = new Elevator("1C");
		Elevator A2 = new Elevator("2A");
		Elevator B2 = new Elevator("2B");
		//put elevators in array
		Elevator [] elevArr = {A1, B1, C1, A2, B2};
		
		Controller elevController = new Controller();
		boolean runElev = true;
		while (runElev) {
			String input = JOptionPane.showInputDialog("Input floor you are on: ");
			int floorRequested = (int) Math.floor(Double.parseDouble(input));
			System.out.println("---------------------\nFloor on (input JOptionPane): " + floorRequested);
			if (floorRequested < 1 || floorRequested > 9) {//there's only 9 floors in teh building
				runElev = false;
				break;
			}
			elevController.addEvent(elevArr, floorRequested);
			
		}
		System.out.println("---------\n------JOptionPane inputs Done-------\n");
		
		//now, loop thru the events and print 
		Controller.printListOfEvents();
		//now, loop thru the elevators and print stuff about them
		for (Elevator e: elevArr) {
			System.out.println(e);
		}
		System.out.println("DONE----------------");

	}

}
